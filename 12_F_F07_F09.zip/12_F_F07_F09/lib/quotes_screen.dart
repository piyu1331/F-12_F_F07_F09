import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class QuotesScreen extends StatefulWidget {
  const QuotesScreen({Key? key}) : super(key: key);

  @override
  _QuotesScreenState createState() => _QuotesScreenState();
}

class _QuotesScreenState extends State<QuotesScreen> {
  String quote = '';
  String author = '';
  String category = '';
  String errorMessage = '';

  @override
  void initState() {
    super.initState();
    fetchQuote();
  }

  Future<void> fetchQuote() async {
    final apiUrl = 'https://api.api-ninjas.com/v1/quotes';
    final response = await http.get(
      Uri.parse(apiUrl),
      headers: {'X-Api-Key': 'yyom+PHRdXBJxuvuPhG9kg==DnKEusFyMRsqJCuR'}, // Replace with your actual API key
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      if (data.isNotEmpty) {
        setState(() {
          quote = data[0]['quote'];
          author = data[0]['author'];
          category = data[0]['category'];
          errorMessage = '';
        });
      }
    } else {
      setState(() {
        errorMessage = 'Error fetching quote: ${response.statusCode}';
        quote = '';
        author = '';
        category = '';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Quotes'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              if (quote.isNotEmpty) ...[
                Text(
                  '"$quote"',
                  style: const TextStyle(fontSize: 24, fontStyle: FontStyle.italic),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                Text(
                  '- $author',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Text(
                  'Category: $category',
                  style: const TextStyle(fontSize: 16),
                ),
              ] else if (errorMessage.isNotEmpty) ...[
                Text(
                  errorMessage,
                  style: const TextStyle(color: Colors.red),
                ),
              ] else ...[
                const CircularProgressIndicator(),
              ],
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: () {
                  fetchQuote(); // Refresh the quote
                },
                child: const Text('Refresh Quote'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
