import 'package:flutter/material.dart';
import 'country_screen.dart'; // Import the new CountrySelectionScreen
import 'quotes_screen.dart'; // Import QuotesScreen

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const CountrySelectionScreen()), // Navigate to CountrySelectionScreen
                );
              },
              child: const Text('Select Country'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const QuotesScreen()), // Navigate to QuotesScreen
                );
              },
              child: const Text('Go to Quotes Screen'),
            ),
          ],
        ),
      ),
    );
  }
}
